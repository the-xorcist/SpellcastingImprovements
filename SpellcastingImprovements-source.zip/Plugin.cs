using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace SpellcastingImprovements
{
    [BepInPlugin("the-xorcist.spellcastingimprovements", "Spellcasting Improvements", "1.1.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }

        /// <summary>
        /// Percentage of movement speed buff that applies to backward movement cap.
        /// Base game caps backward speed at 7, regardless of buffs.
        /// At 50%, a +5 movement buff increases the backward cap from 7 to 9.5.
        /// </summary>
        public static ConfigEntry<float> BackwardSpeedBuffPercent;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("Spellcasting Improvements: Initializing...");

            // Bind config entries
            BackwardSpeedBuffPercent = Config.Bind(
                "Movement Speed",
                "BackwardSpeedBuffPercent",
                50f,
                new ConfigDescription(
                    "Percentage of movement speed buff that applies to backward movement speed cap. " +
                    "Base game caps backward speed at 7. At 50%, a +5 buff increases cap to 9.5. " +
                    "Set to 0 to disable, 100 for full buff application.",
                    new AcceptableValueRange<float>(0f, 100f)));

            Harmony harmony = new Harmony("the-xorcist.spellcastingimprovements");
            harmony.PatchAll();
            Logger.LogInfo("Spellcasting Improvements: Harmony patches applied.");
        }
    }
}

