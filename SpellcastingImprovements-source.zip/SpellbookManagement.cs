using System.Collections.Generic;
using HarmonyLib;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SpellcastingImprovements
{
    /// <summary>
    /// Provides spellbook management features:
    /// - Move/Swap spells: Right-click to select (with twinkling animation), then click to move/swap
    /// - Delete spells: Delete button with confirmation dialog
    /// </summary>
    public static class SpellbookManagement
    {
        // State for move/swap mode
        private static SpellbookSlot _selectedSlotForMove = null;
        private static Spell _selectedSpellForMove = null;
        private static int _selectedSpellIndex = -1;
        private static float _twinkleTimer = 0f;
        private static bool _twinkleState = false;

        // Colors for twinkling animation
        private static readonly Color TwinkleColor1 = Color.white;
        private static readonly Color TwinkleColor2 = Color.yellow;
        private static readonly Color TwinkleColor3 = new Color(1f, 0.9f, 0.5f); // Light gold
        private static readonly float TwinkleSpeed = 0.15f; // Seconds per color change

        // Delete confirmation state
        private static bool _showDeleteConfirm = false;
        private static Spell _spellToDelete = null;
        private static SpellBook _currentSpellBook = null;

        /// <summary>
        /// Gets whether move mode is active (spell selected for move/swap)
        /// </summary>
        public static bool IsMoveMode => _selectedSpellForMove != null && _selectedSpellIndex >= 0;

        /// <summary>
        /// Gets the currently selected spell for move/swap
        /// </summary>
        public static Spell SelectedSpell => _selectedSpellForMove;

        /// <summary>
        /// Called every frame to update twinkling animation
        /// </summary>
        public static void UpdateTwinkle()
        {
            if (_selectedSlotForMove == null || _selectedSlotForMove.SlotBG == null)
                return;

            _twinkleTimer += Time.deltaTime;
            if (_twinkleTimer >= TwinkleSpeed)
            {
                _twinkleTimer = 0f;
                _twinkleState = !_twinkleState;

                // Cycle through colors for twinkling effect
                int colorIndex = (int)(Time.time / TwinkleSpeed) % 3;
                Color twinkleColor = colorIndex switch
                {
                    0 => TwinkleColor1,
                    1 => TwinkleColor2,
                    _ => TwinkleColor3
                };
                _selectedSlotForMove.SlotBG.color = twinkleColor;
            }
        }

        /// <summary>
        /// Enters move mode for the given slot
        /// </summary>
        public static void EnterMoveMode(SpellbookSlot slot, SpellBook spellBook)
        {
            if (slot == null || slot.AssignedSpell == null)
                return;

            // Calculate the index in KnownSpells
            int page = spellBook.GetPage();
            int slotIndex = spellBook.Slots.IndexOf(slot);
            if (slotIndex < 0) return;

            int spellIndex = page * 12 + slotIndex;
            var knownSpells = GameData.PlayerControl.GetComponent<CastSpell>().KnownSpells;
            if (spellIndex < 0 || spellIndex >= knownSpells.Count)
                return;

            _selectedSlotForMove = slot;
            _selectedSpellForMove = slot.AssignedSpell;
            _selectedSpellIndex = spellIndex;
            _currentSpellBook = spellBook;
            _twinkleTimer = 0f;

            Debug.Log($"[SpellbookManagement] Entered move mode for '{_selectedSpellForMove.SpellName}' at index {_selectedSpellIndex}");
            UpdateSocialLog.LogAdd($"Selected {_selectedSpellForMove.SpellName} - click another slot to move/swap.", "lightblue");
        }

        /// <summary>
        /// Exits move mode without performing any action
        /// </summary>
        public static void ExitMoveMode()
        {
            ClearTwinkleVisual();

            _selectedSlotForMove = null;
            _selectedSpellForMove = null;
            _selectedSpellIndex = -1;
            _currentSpellBook = null;
        }

        /// <summary>
        /// Clears the twinkling visual effect without exiting move mode.
        /// Used when changing pages to clear the visual on the old slot.
        /// </summary>
        public static void ClearTwinkleVisual()
        {
            if (_selectedSlotForMove != null && _selectedSlotForMove.SlotBG != null)
            {
                // Reset color to black (deselected state)
                _selectedSlotForMove.SlotBG.color = Color.black;
            }
            // Note: We keep _selectedSlotForMove reference for now,
            // but the slot is no longer on the current page so we null it
            _selectedSlotForMove = null;
        }

        /// <summary>
        /// Handles clicking on a target slot while in move mode
        /// </summary>
        public static void HandleMoveTarget(SpellbookSlot targetSlot, SpellBook spellBook)
        {
            // Check if we're in move mode (spell selected, not necessarily same page)
            if (!IsMoveMode || _selectedSpellForMove == null)
                return;

            // Calculate target index
            int page = spellBook.GetPage();
            int slotIndex = spellBook.Slots.IndexOf(targetSlot);
            if (slotIndex < 0) return;

            int targetIndex = page * 12 + slotIndex;
            var knownSpells = GameData.PlayerControl.GetComponent<CastSpell>().KnownSpells;

            // Same position - just exit move mode
            if (targetIndex == _selectedSpellIndex)
            {
                ExitMoveMode();
                return;
            }

            string sourceSpellName = _selectedSpellForMove.SpellName;

            if (targetSlot.AssignedSpell != null)
            {
                // Swap with existing spell
                SwapSpells(_selectedSpellIndex, targetIndex, knownSpells);
                UpdateSocialLog.LogAdd($"Swapped {sourceSpellName} with {targetSlot.AssignedSpell.SpellName}.", "lightblue");
            }
            else
            {
                // Move to empty slot (end of list)
                MoveSpellToIndex(_selectedSpellIndex, targetIndex, knownSpells);
                UpdateSocialLog.LogAdd($"Moved {sourceSpellName} to new position.", "lightblue");
            }

            ExitMoveMode();
            spellBook.UpdateSpellList(page);
        }

        private static void SwapSpells(int indexA, int indexB, List<Spell> spells)
        {
            if (indexA < 0 || indexA >= spells.Count || indexB < 0 || indexB >= spells.Count)
                return;

            Spell temp = spells[indexA];
            spells[indexA] = spells[indexB];
            spells[indexB] = temp;
            Debug.Log($"[SpellbookManagement] Swapped spells at indices {indexA} and {indexB}");
        }

        private static void MoveSpellToIndex(int fromIndex, int toIndex, List<Spell> spells)
        {
            if (fromIndex < 0 || fromIndex >= spells.Count)
                return;

            // Clamp toIndex to valid range (can be at end for appending)
            toIndex = Mathf.Clamp(toIndex, 0, spells.Count);

            Spell spell = spells[fromIndex];
            spells.RemoveAt(fromIndex);

            // Adjust toIndex if we removed before it
            if (fromIndex < toIndex)
                toIndex--;

            spells.Insert(toIndex, spell);
            Debug.Log($"[SpellbookManagement] Moved spell from index {fromIndex} to {toIndex}");
        }

        /// <summary>
        /// Initiates delete confirmation for the given spell
        /// </summary>
        public static void InitiateDelete(SpellBook spellBook)
        {
            if (spellBook.CurrentSelection == null || spellBook.CurrentSelection.AssignedSpell == null)
            {
                UpdateSocialLog.LogAdd("Select a spell first to delete it.", "yellow");
                return;
            }

            _spellToDelete = spellBook.CurrentSelection.AssignedSpell;
            _currentSpellBook = spellBook;
            _showDeleteConfirm = true;
        }

        /// <summary>
        /// Confirms and performs the delete
        /// </summary>
        public static void ConfirmDelete()
        {
            if (_spellToDelete == null)
                return;

            var knownSpells = GameData.PlayerControl.GetComponent<CastSpell>().KnownSpells;
            string spellName = _spellToDelete.SpellName;

            if (knownSpells.Remove(_spellToDelete))
            {
                Debug.Log($"[SpellbookManagement] Deleted spell '{spellName}' from spellbook");
                UpdateSocialLog.LogAdd($"Removed {spellName} from your spellbook.", "lightblue");

                if (_currentSpellBook != null)
                {
                    _currentSpellBook.UpdateSpellList(_currentSpellBook.GetPage());
                }
            }
            else
            {
                UpdateSocialLog.LogAdd($"Failed to remove {spellName}.", "red");
            }

            CancelDelete();
        }

        /// <summary>
        /// Cancels the delete operation
        /// </summary>
        public static void CancelDelete()
        {
            _showDeleteConfirm = false;
            _spellToDelete = null;
        }

        /// <summary>
        /// Returns true if the delete confirmation dialog should be shown
        /// </summary>
        public static bool ShouldShowDeleteConfirm => _showDeleteConfirm;

        /// <summary>
        /// Gets the name of the spell being deleted (for confirmation dialog)
        /// </summary>
        public static string SpellToDeleteName => _spellToDelete?.SpellName ?? "";
    }

    /// <summary>
    /// Patches SpellbookSlot to handle right-click for move mode and left-click while in move mode
    /// </summary>
    [HarmonyPatch(typeof(SpellbookSlot), "OnPointerDown")]
    public class SpellbookSlot_OnPointerDown_Patch
    {
        private static bool Prefix(SpellbookSlot __instance, PointerEventData eventData)
        {
            // Skip if this is the HKOnly slot (the draggable hotkey slot)
            if (__instance.HKOnly)
                return true;

            // Right-click: Enter move mode
            if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (__instance.AssignedSpell != null)
                {
                    // If already in move mode with a different slot, exit first
                    if (SpellbookManagement.IsMoveMode)
                    {
                        SpellbookManagement.ExitMoveMode();
                    }
                    SpellbookManagement.EnterMoveMode(__instance, __instance.SB);
                }
                return false; // Don't run original
            }

            // Left-click while in move mode: perform move/swap
            if (eventData.button == PointerEventData.InputButton.Left && SpellbookManagement.IsMoveMode)
            {
                SpellbookManagement.HandleMoveTarget(__instance, __instance.SB);
                return false; // Don't run original
            }

            return true; // Run original for normal left-click
        }
    }

    /// <summary>
    /// Patches SpellbookSlot.Update to handle twinkling animation
    /// </summary>
    [HarmonyPatch(typeof(SpellbookSlot), "Update")]
    public class SpellbookSlot_Update_Patch
    {
        private static void Postfix()
        {
            SpellbookManagement.UpdateTwinkle();
        }
    }

    /// <summary>
    /// Patches SpellBook.OpenCloseSpellbook to exit move mode when closing and create delete button when opening
    /// </summary>
    [HarmonyPatch(typeof(SpellBook), "OpenCloseSpellbook")]
    public class SpellBook_OpenCloseSpellbook_Patch
    {
        private static void Postfix(SpellBook __instance, GameObject ___Spellbook)
        {
            if (___Spellbook.activeSelf)
            {
                // Spellbook opened - ensure delete button exists
                DeleteButtonManager.EnsureDeleteButton(__instance, ___Spellbook);
            }
            else
            {
                // Spellbook closed - exit move mode
                SpellbookManagement.ExitMoveMode();
                SpellbookManagement.CancelDelete();
            }
        }
    }

    /// <summary>
    /// Patches SpellBook.Update to handle ESC key for delete confirmation
    /// </summary>
    [HarmonyPatch(typeof(SpellBook), "Update")]
    public class SpellBook_Update_Patch
    {
        private static void Postfix()
        {
            if (SpellbookManagement.ShouldShowDeleteConfirm && Input.GetKeyDown(KeyCode.Escape))
            {
                SpellbookManagement.CancelDelete();
            }
        }
    }

    /// <summary>
    /// Patches SpellBook.PageForward to implement page limits and wrapping
    /// </summary>
    [HarmonyPatch(typeof(SpellBook), "PageForward")]
    public class SpellBook_PageForward_Patch
    {
        private static bool Prefix(SpellBook __instance, ref int ___curPage)
        {
            // Don't exit move mode - allow cross-page swaps
            // Just clear the visual twinkling on current slot before page change
            SpellbookManagement.ClearTwinkleVisual();

            var knownSpells = GameData.PlayerControl.GetComponent<CastSpell>().KnownSpells;
            int spellCount = knownSpells.Count;

            // Calculate the last valid page (page with spells + 1 empty page)
            // If 0 spells: lastPage = 0 (just show empty page 1)
            // If 1-12 spells: lastPage = 1 (page 1 has spells, page 2 is empty)
            // If 13-24 spells: lastPage = 2 (pages 1-2 have spells, page 3 is empty)
            int lastPage = spellCount > 0 ? (spellCount - 1) / 12 + 1 : 0;

            ___curPage++;
            if (___curPage > lastPage)
            {
                ___curPage = 0; // Wrap to first page
            }

            __instance.UpdateSpellList(___curPage);
            return false; // Don't run original
        }
    }

    /// <summary>
    /// Patches SpellBook.PageBack to implement page limits and wrapping
    /// </summary>
    [HarmonyPatch(typeof(SpellBook), "PageBack")]
    public class SpellBook_PageBack_Patch
    {
        private static bool Prefix(SpellBook __instance, ref int ___curPage)
        {
            // Don't exit move mode - allow cross-page swaps
            // Just clear the visual twinkling on current slot before page change
            SpellbookManagement.ClearTwinkleVisual();

            var knownSpells = GameData.PlayerControl.GetComponent<CastSpell>().KnownSpells;
            int spellCount = knownSpells.Count;

            // Calculate the last valid page (same logic as PageForward)
            int lastPage = spellCount > 0 ? (spellCount - 1) / 12 + 1 : 0;

            ___curPage--;
            if (___curPage < 0)
            {
                ___curPage = lastPage; // Wrap to last page (the empty page)
            }

            __instance.UpdateSpellList(___curPage);
            return false; // Don't run original
        }
    }

    /// <summary>
    /// Static manager for creating and managing the Delete Spell button
    /// </summary>
    public static class DeleteButtonManager
    {
        private static Button _deleteButton = null;
        private static bool _buttonCreated = false;

        /// <summary>
        /// Ensures the delete button exists on the spellbook UI
        /// Called from OpenCloseSpellbook postfix when spellbook opens
        /// </summary>
        public static void EnsureDeleteButton(SpellBook spellBook, GameObject spellbookObj)
        {
            // Check if button already exists
            if (_buttonCreated && _deleteButton != null)
                return;

            // Also ensure the confirmation dialog renderer exists
            EnsureConfirmDialogRenderer(spellbookObj);

            // Find the "View Skills" button to clone from (it has proper text styling)
            var viewSkillsButton = FindViewSkillsButton(spellbookObj.transform);
            if (viewSkillsButton == null)
            {
                Debug.LogWarning("[SpellbookManagement] Could not find View Skills button to clone");
                return;
            }

            // Find the Hotkey dropdown for positioning reference
            var hotkeyDropdown = spellBook.Hotkey;

            // Create Delete button by cloning the View Skills button
            var deleteButtonObj = Object.Instantiate(viewSkillsButton.gameObject, viewSkillsButton.transform.parent);
            deleteButtonObj.name = "DeleteSpellButton";

            // Position it below the Hotkey dropdown (or below View Skills if dropdown not found)
            var rectTransform = deleteButtonObj.GetComponent<RectTransform>();
            if (rectTransform != null)
            {
                if (hotkeyDropdown != null)
                {
                    // Position relative to the Hotkey dropdown
                    var dropdownRect = hotkeyDropdown.GetComponent<RectTransform>();
                    if (dropdownRect != null)
                    {
                        // Copy the X position from dropdown, position below it
                        var pos = rectTransform.anchoredPosition;
                        pos.x = dropdownRect.anchoredPosition.x;
                        pos.y = dropdownRect.anchoredPosition.y - dropdownRect.rect.height - 10f;
                        rectTransform.anchoredPosition = pos;
                        Debug.Log($"[SpellbookManagement] Positioned delete button below dropdown at {pos}");
                    }
                }
                else
                {
                    // Fallback: position below the View Skills button
                    var sourceRect = viewSkillsButton.GetComponent<RectTransform>();
                    if (sourceRect != null)
                    {
                        var pos = rectTransform.anchoredPosition;
                        pos.y -= sourceRect.rect.height + 10f;
                        rectTransform.anchoredPosition = pos;
                        Debug.Log($"[SpellbookManagement] Positioned delete button below View Skills at {pos}");
                    }
                }
            }

            // Update button text
            var buttonText = deleteButtonObj.GetComponentInChildren<TMPro.TextMeshProUGUI>();
            if (buttonText != null)
            {
                buttonText.text = "Delete Spell";
            }

            // Setup button click handler - completely replace all click behavior
            _deleteButton = deleteButtonObj.GetComponent<Button>();
            if (_deleteButton != null)
            {
                // Remove ALL persistent and runtime listeners
                _deleteButton.onClick.RemoveAllListeners();
                _deleteButton.onClick = new Button.ButtonClickedEvent();
                _deleteButton.onClick.AddListener(() => SpellbookManagement.InitiateDelete(spellBook));
            }

            // Remove any other components that might trigger tab switching
            // (e.g., EventTrigger, custom click handlers)
            var eventTriggers = deleteButtonObj.GetComponents<EventTrigger>();
            foreach (var trigger in eventTriggers)
            {
                Object.Destroy(trigger);
            }

            _buttonCreated = true;
            Debug.Log("[SpellbookManagement] Delete button created successfully");
        }

        private static void EnsureConfirmDialogRenderer(GameObject spellbookObj)
        {
            // Add the confirmation dialog renderer to the spellbook's GameObject
            // This ensures it gets Unity's game loop (Update, OnGUI, etc.)
            if (spellbookObj.GetComponent<ConfirmDialogRenderer>() == null)
            {
                spellbookObj.AddComponent<ConfirmDialogRenderer>();
                Debug.Log("[SpellbookManagement] ConfirmDialogRenderer added to spellbook");
            }
        }

        private static Button FindViewSkillsButton(Transform root)
        {
            var allButtons = root.GetComponentsInChildren<Button>(true);

            // Look for "View Skills" button (has proper text styling)
            foreach (var button in allButtons)
            {
                var text = button.GetComponentInChildren<TMPro.TextMeshProUGUI>();
                if (text != null && text.text.Contains("View Skills"))
                {
                    Debug.Log($"[SpellbookManagement] Found View Skills button: '{button.name}'");
                    return button;
                }
            }

            // Fallback: look for any button with text
            foreach (var button in allButtons)
            {
                var text = button.GetComponentInChildren<TMPro.TextMeshProUGUI>();
                if (text != null && !string.IsNullOrEmpty(text.text))
                {
                    Debug.Log($"[SpellbookManagement] Using fallback button with text: '{text.text}'");
                    return button;
                }
            }

            return null;
        }
    }

    /// <summary>
    /// Minimal MonoBehaviour attached to the spellbook to handle OnGUI rendering for confirmation dialog
    /// </summary>
    public class ConfirmDialogRenderer : MonoBehaviour
    {
        private void OnGUI()
        {
            // Draw confirmation dialog using IMGUI
            if (SpellbookManagement.ShouldShowDeleteConfirm)
            {
                DrawConfirmDialog();
            }
        }

        private void DrawConfirmDialog()
        {
            float dialogWidth = 300f;
            float dialogHeight = 120f;
            float x = (Screen.width - dialogWidth) / 2f;
            float y = (Screen.height - dialogHeight) / 2f;

            // Semi-transparent background overlay
            GUI.color = new Color(0, 0, 0, 0.5f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = Color.white;

            // Dialog box
            GUIStyle boxStyle = new GUIStyle(GUI.skin.box);
            boxStyle.fontSize = 14;
            GUI.Box(new Rect(x, y, dialogWidth, dialogHeight), "");

            // Title
            GUIStyle titleStyle = new GUIStyle(GUI.skin.label);
            titleStyle.fontSize = 16;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.alignment = TextAnchor.MiddleCenter;
            GUI.Label(new Rect(x, y + 10, dialogWidth, 25), "Delete Spell?", titleStyle);

            // Message
            GUIStyle msgStyle = new GUIStyle(GUI.skin.label);
            msgStyle.alignment = TextAnchor.MiddleCenter;
            msgStyle.wordWrap = true;
            GUI.Label(new Rect(x + 10, y + 35, dialogWidth - 20, 40),
                $"Remove {SpellbookManagement.SpellToDeleteName} from your spellbook?", msgStyle);

            // Buttons
            float btnWidth = 80f;
            float btnHeight = 30f;
            float btnY = y + dialogHeight - btnHeight - 15f;

            if (GUI.Button(new Rect(x + dialogWidth / 2 - btnWidth - 10, btnY, btnWidth, btnHeight), "Yes"))
            {
                SpellbookManagement.ConfirmDelete();
            }

            if (GUI.Button(new Rect(x + dialogWidth / 2 + 10, btnY, btnWidth, btnHeight), "No"))
            {
                SpellbookManagement.CancelDelete();
            }
        }
    }
}
