using HarmonyLib;
using UnityEngine;
using System.Collections.Generic;

namespace SpellcastingImprovements
{
    /// <summary>
    /// Prevents DoT (damage over time) damage from triggering the 20% chance to break
    /// UnstableDuration effects like roots and mezzes.
    ///
    /// The vanilla game calls RemoveBreakableEffects() for ALL damage, including DoT ticks.
    /// This means every DoT tick has a 20% chance to break roots/mezzes on the target,
    /// which seems unintentional - DoTs should not break CC effects.
    ///
    /// Implementation:
    /// 1. Prefix on Character.DamageMe sets a flag when _animEffect=false (DoT signature)
    /// 2. Prefix on Stats.RemoveBreakableEffects provides alternative implementation during DoT
    ///    - BreakOnDamage effects still break normally
    ///    - UnstableDuration 20% check is skipped
    /// 3. Postfix on Character.DamageMe clears the flag
    /// </summary>
    public static class DoTBreakChanceFixer
    {
        /// <summary>
        /// Tracks whether we're currently processing DoT damage.
        /// When true, RemoveBreakableEffects should skip the 20% UnstableDuration break logic.
        /// BreakOnDamage effects still break normally.
        /// </summary>
        public static bool IsProcessingDoTDamage { get; set; } = false;

        /// <summary>
        /// Enable verbose logging for CC break events.
        /// </summary>
        public static bool EnableCCBreakLogging { get; set; } = true;

        /// <summary>
        /// Prefix on DamageMe to detect DoT damage.
        /// DoT calls use _animEffect=false and _criticalHit=false as signature.
        /// We also check that _bonusDmg is 0 (default) which DoTs use.
        /// </summary>
        [HarmonyPatch(typeof(Character), "DamageMe")]
        public class Character_DamageMe_Prefix
        {
            static void Prefix(bool _animEffect, bool _criticalHit, int _bonusDmg)
            {
                // DoT damage signature: _animEffect=false, _criticalHit=false, _bonusDmg=0 (default)
                // Direct melee/ranged damage uses _animEffect=true for hit animations
                if (!_animEffect && !_criticalHit && _bonusDmg == 0)
                {
                    IsProcessingDoTDamage = true;
                }
            }
        }

        /// <summary>
        /// Postfix on DamageMe to clear the DoT flag after processing.
        /// </summary>
        [HarmonyPatch(typeof(Character), "DamageMe")]
        public class Character_DamageMe_Postfix
        {
            static void Postfix()
            {
                IsProcessingDoTDamage = false;
            }
        }

        /// <summary>
        /// Prefix on RemoveBreakableEffects that provides an alternative implementation during DoT damage.
        ///
        /// During DoT damage:
        /// - BreakOnDamage effects still break normally
        /// - UnstableDuration effects do NOT get the 20% break chance
        ///
        /// During non-DoT damage:
        /// - Original method runs (both BreakOnDamage and 20% chance work)
        /// </summary>
        [HarmonyPatch(typeof(Stats), "RemoveBreakableEffects")]
        public class Stats_RemoveBreakableEffects_Prefix
        {
            static bool Prefix(Stats __instance)
            {
                // If not DoT damage, run the original method
                if (!IsProcessingDoTDamage)
                    return true;

                // During DoT damage, only process BreakOnDamage effects
                // Skip the 20% chance for UnstableDuration effects
                if (__instance.StatusEffects == null)
                    return false;

                for (int i = 0; i <= __instance.StatusEffects.Length - 1; i++)
                {
                    if (__instance.StatusEffects[i] != null &&
                        __instance.StatusEffects[i].Effect != null &&
                        __instance.StatusEffects[i].Effect.BreakOnDamage)
                    {
                        string spellName = __instance.StatusEffects[i].Effect.SpellName;
                        string targetName = __instance.MyName ?? __instance.transform?.name ?? "target";

                        __instance.RemoveStatusEffect(i);

                        if (EnableCCBreakLogging)
                        {
                            Debug.Log($"[SpellcastingImprovements] CC BROKEN (BreakOnDamage): {spellName} on {targetName} - DoT broke BreakOnDamage effect");
                        }
                    }
                    // Skip the UnstableDuration 20% check entirely during DoT
                    // This is the fix - DoTs no longer break roots/mezzes with the 20% chance
                }

                return false; // Skip original method
            }
        }

        /// <summary>
        /// Prefix on RemoveBreakableEffects to log when CC effects might break.
        /// Captures the state of active UnstableDuration effects before they might be removed.
        /// </summary>
        [HarmonyPatch(typeof(Stats), "RemoveBreakableEffects")]
        public class Stats_RemoveBreakableEffects_LogPrefix
        {
            static void Prefix(Stats __instance, out List<string> __state)
            {
                __state = new List<string>();

                if (!EnableCCBreakLogging || __instance?.StatusEffects == null) return;

                // Capture all active UnstableDuration effects before RemoveBreakableEffects runs
                for (int i = 0; i < __instance.StatusEffects.Length; i++)
                {
                    var effect = __instance.StatusEffects[i];
                    if (effect?.Effect != null && effect.Effect.UnstableDuration && effect.Duration > 0)
                    {
                        __state.Add($"{effect.Effect.SpellName}:{i}:{effect.Duration:F1}");
                    }
                }
            }
        }

        /// <summary>
        /// Postfix on RemoveBreakableEffects to log which CC effects were broken or preserved.
        /// Compares against prefix state to determine what happened.
        /// </summary>
        [HarmonyPatch(typeof(Stats), "RemoveBreakableEffects")]
        public class Stats_RemoveBreakableEffects_LogPostfix
        {
            static void Postfix(Stats __instance, List<string> __state)
            {
                if (!EnableCCBreakLogging || __state == null || __state.Count == 0) return;

                string targetName = __instance?.MyName ?? __instance?.transform?.name ?? "unknown";
                bool wasDoT = IsProcessingDoTDamage;

                // Check which effects are still active
                foreach (string effectInfo in __state)
                {
                    var parts = effectInfo.Split(':');
                    if (parts.Length < 3) continue;

                    string spellName = parts[0];
                    if (!int.TryParse(parts[1], out int index)) continue;

                    bool stillActive = index < __instance.StatusEffects.Length &&
                                      __instance.StatusEffects[index]?.Effect != null &&
                                      __instance.StatusEffects[index].Duration > 0;

                    if (!stillActive)
                    {
                        // Effect was removed
                        Debug.Log($"[SpellcastingImprovements] CC BROKEN: {spellName} on {targetName} " +
                                 $"(wasDoT={wasDoT}, BreakOnDamage={__instance.StatusEffects[index]?.Effect?.BreakOnDamage ?? false})");
                    }
                    else if (wasDoT)
                    {
                        // Effect preserved during DoT - our fix worked!
                        Debug.Log($"[SpellcastingImprovements] CC PRESERVED (DoT): {spellName} on {targetName} " +
                                 $"- 20% break chance skipped");
                    }
                }
            }
        }
    }

    /// <summary>
    /// Adds a chat message when targets break free from CC effects due to resist checks.
    /// Also logs detailed resist check information for debugging.
    ///
    /// When the per-tick resist check succeeds (target resists), the vanilla game just
    /// silently sets Duration = 0. This adds a visible message:
    /// "[TargetName] breaks free from your [SpellName]!"
    ///
    /// Only shows for player-cast effects to avoid spam.
    /// </summary>
    [HarmonyPatch(typeof(Stats), "TickEffects")]
    public static class ResistBreakNotifier
    {
        /// <summary>
        /// Data structure to track an effect with all resist check details.
        /// </summary>
        private struct TrackedEffect
        {
            public int Index;
            public string SpellName;
            public float Duration;
            public int SpellLevel;
            public GameData.DamageType DamageType;
            public int TargetResist;
            public float BreakChance;
        }

        /// <summary>
        /// Enable verbose logging for debugging.
        /// </summary>
        public static bool EnableVerboseLogging = false;

        /// <summary>
        /// Track real time for measuring tick intervals.
        /// </summary>
        private static float _lastTickTime = 0f;
        private static bool _firstTick = true;

        /// <summary>
        /// Track active CC effects to measure total duration.
        /// Key: "TargetName|SlotIndex|SpellName"
        /// Value: (StartTime, InitialDuration)
        /// </summary>
        private static Dictionary<string, (float startTime, float initialDuration)> _activeEffects =
            new Dictionary<string, (float, float)>();

        /// <summary>
        /// Prefix: Capture UnstableDuration player-cast effects and log resist check details.
        /// </summary>
        static void Prefix(Stats __instance, out List<TrackedEffect> __state)
        {
            __state = new List<TrackedEffect>();

            if (__instance?.StatusEffects == null) return;

            string targetName = __instance.MyName ?? __instance.transform?.name ?? "target";

            for (int i = 0; i < __instance.StatusEffects.Length; i++)
            {
                var se = __instance.StatusEffects[i];
                if (se?.Effect == null) continue;

                // Only track UnstableDuration effects from the player
                if (se.Effect.UnstableDuration && se.fromPlayer && se.Duration > 0f)
                {
                    var spell = se.Effect;
                    int spellLevel = spell.RequiredLevel;
                    int rangeMax = spellLevel * 100;

                    // Get the target's resist for this damage type
                    int targetResist = __instance.CheckResistSimple(spell.MyDamageType);

                    // Calculate break chance: resist / (spellLevel * 100)
                    float breakChance = rangeMax > 0 ? (float)targetResist / rangeMax * 100f : 0f;

                    __state.Add(new TrackedEffect
                    {
                        Index = i,
                        SpellName = spell.SpellName,
                        Duration = se.Duration,
                        SpellLevel = spellLevel,
                        DamageType = spell.MyDamageType,
                        TargetResist = targetResist,
                        BreakChance = breakChance
                    });

                    // Track when this effect started (if not already tracked)
                    string effectKey = $"{targetName}|{i}|{spell.SpellName}";
                    float currentTime = UnityEngine.Time.time;

                    if (!_activeEffects.ContainsKey(effectKey))
                    {
                        _activeEffects[effectKey] = (currentTime, se.Duration);
                        Debug.Log($"[SpellcastingImprovements] CC STARTED: {spell.SpellName} on {targetName} (slot {i}) | " +
                                 $"InitialDuration: {se.Duration:F1} ticks | StartTime: {currentTime:F2}s");
                    }

                    if (EnableVerboseLogging && se.Duration > 2f)
                    {
                        // Measure real time between ticks
                        float tickInterval = _firstTick ? 0f : (currentTime - _lastTickTime);
                        _lastTickTime = currentTime;
                        _firstTick = false;

                        Debug.Log($"[SpellcastingImprovements] RESIST CHECK: {spell.SpellName} on {targetName} (slot {i}) | " +
                                 $"Duration: {se.Duration:F1} ticks | SpellLvl: {spellLevel} | " +
                                 $"TargetResist: {targetResist} | BreakChance: {breakChance:F1}% | " +
                                 $"RealTime: {currentTime:F2}s (interval: {tickInterval:F2}s)");
                    }
                }
            }
        }

        /// <summary>
        /// Postfix: Check if any tracked effects are now gone - log total duration and resist breaks.
        /// </summary>
        static void Postfix(Stats __instance, List<TrackedEffect> __state)
        {
            if (__state == null || __state.Count == 0) return;
            if (__instance?.StatusEffects == null) return;

            string targetName = __instance.MyName ?? __instance.transform?.name ?? "target";
            float currentTime = UnityEngine.Time.time;

            foreach (var tracked in __state)
            {
                var currentEffect = __instance.StatusEffects[tracked.Index];

                // Effect is gone or duration is now <= 0
                bool effectGone = currentEffect?.Effect == null || currentEffect.Duration <= 0f;

                // Build the effect key for tracking
                string effectKey = $"{targetName}|{tracked.Index}|{tracked.SpellName}";

                if (effectGone)
                {
                    // Calculate and log total duration
                    if (_activeEffects.TryGetValue(effectKey, out var trackingData))
                    {
                        float totalDuration = currentTime - trackingData.startTime;
                        string reason = tracked.Duration > 2f ? "ResistBreak" : "Natural";

                        Debug.Log($"[SpellcastingImprovements] CC ENDED: {tracked.SpellName} on {targetName} (slot {tracked.Index}) | " +
                                 $"TotalDuration: {totalDuration:F2}s | InitialTicks: {trackingData.initialDuration:F1} | " +
                                 $"Reason: {reason}");

                        _activeEffects.Remove(effectKey);
                    }

                    // Report resist breaks for effects that had more than 2 ticks left
                    if (tracked.Duration > 2f)
                    {
                        // This was a resist break!
                        UpdateSocialLog.LogAdd($"{targetName} breaks free from your {tracked.SpellName}!", "yellow");
                        Debug.Log($"[SpellcastingImprovements] RESIST BREAK! {targetName} broke free from {tracked.SpellName} | " +
                                 $"Had {tracked.Duration:F1} ticks left | SpellLvl: {tracked.SpellLevel} | " +
                                 $"Resist: {tracked.TargetResist} | BreakChance was {tracked.BreakChance:F1}%");
                    }
                }
            }
        }
    }

    /// <summary>
    /// Fixes spell stacking - when a higher level spell on the same line is cast,
    /// removes any existing lower level spells on that line first.
    /// The base game only blocks lower-level spells, but doesn't remove them when
    /// casting a higher-level replacement.
    /// </summary>
    [HarmonyPatch(typeof(Stats), "AddStatusEffect", new System.Type[] { typeof(Spell), typeof(bool), typeof(int), typeof(Character) })]
    public class Stats_RemoveLowerLevelSpells_Patch
    {
        // Run before the main AddStatusEffect to clean up lower-level spells
        [HarmonyPriority(Priority.High)]
        private static void Prefix(Stats __instance, Spell spell)
        {
            if (spell == null || spell.Type != Spell.SpellType.Beneficial)
                return;

            // Skip if Generic line (those don't stack-check)
            if (spell.Line == Spell.SpellLine.Generic)
                return;

            // Find and remove any lower-level spells on the same line
            for (int i = 0; i < __instance.StatusEffects.Length; i++)
            {
                var se = __instance.StatusEffects[i];
                if (se == null || se.Effect == null)
                    continue;

                // Same spell line, and existing spell is LOWER level
                if (se.Effect.Line == spell.Line && se.Effect.RequiredLevel < spell.RequiredLevel)
                {
                    Debug.Log($"[SpellcastingImprovements] Removing '{se.Effect.SpellName}' (level {se.Effect.RequiredLevel}) " +
                              $"to make room for '{spell.SpellName}' (level {spell.RequiredLevel})");
                    __instance.RemoveStatusEffect(i);
                }
            }
        }
    }

    /// <summary>
    /// Fixes the bug where beneficial spell status messages appear even when the spell
    /// doesn't take hold due to a higher level spell already being active.
    /// This is a bug in the base game where SpellVessel.ResolveSpell() shows the status
    /// message BEFORE checking CheckForHigherLevelSE().
    /// </summary>
    public static class SpellMessageFixer
    {
        // State tracking for beneficial spell resolution
        private static bool _isResolvingBeneficialSpell = false;
        private static Spell _currentSpell = null;
        private static bool _spellWasBlocked = false;

        /// <summary>
        /// Prefix patch for SpellVessel.ResolveSpell() - tracks when beneficial spells
        /// are being resolved and pre-checks if they'll be blocked.
        /// </summary>
        [HarmonyPatch(typeof(SpellVessel), "ResolveSpell")]
        public class SpellVessel_ResolveSpell_Patch
        {
            private static void Prefix(Spell ___spell, Stats ___targ)
            {
                if (___spell != null && ___spell.Type == Spell.SpellType.Beneficial)
                {
                    _isResolvingBeneficialSpell = true;
                    _currentSpell = ___spell;

                    // Pre-check if spell will be blocked by a higher level spell
                    if (___targ != null && ___targ.Myself != null && !___targ.Myself.Invulnerable)
                    {
                        _spellWasBlocked = ___targ.Myself.MyStats.CheckForHigherLevelSE(___spell);
                    }
                    else
                    {
                        _spellWasBlocked = false;
                    }
                }
            }

            private static void Postfix()
            {
                // Clean up state after ResolveSpell completes
                _isResolvingBeneficialSpell = false;
                _currentSpell = null;
                _spellWasBlocked = false;
            }
        }

        /// <summary>
        /// Prefix patch for UpdateSocialLog.LogAdd() - intercepts status effect messages
        /// during beneficial spell resolution and replaces them with "did not take hold"
        /// message if the spell was blocked.
        /// </summary>
        [HarmonyPatch(typeof(UpdateSocialLog), "LogAdd", typeof(string), typeof(string))]
        public class UpdateSocialLog_LogAdd_Patch
        {
            private static bool Prefix(ref string _string, ref string _colorAsString)
            {
                // Fast path - not resolving a beneficial spell
                if (!_isResolvingBeneficialSpell || _currentSpell == null)
                    return true;

                // Check if this is the status effect message for the current spell
                // The message format is "You " + spell.StatusEffectMessageOnPlayer
                if (_string.StartsWith("You ") && _currentSpell.StatusEffectMessageOnPlayer != null &&
                    _string.Contains(_currentSpell.StatusEffectMessageOnPlayer))
                {
                    if (_spellWasBlocked)
                    {
                        // Replace with "did not take hold" message in red
                        _string = "Your spell did not take hold.";
                        _colorAsString = "red";
                    }
                }

                return true; // Let the (possibly modified) message through
            }
        }
    }

    /// <summary>
    /// Allows players to click on their buff icons to remove beneficial spells.
    /// Single-clicking a buff icon removes the buff and all its effects.
    ///
    /// Restrictions:
    /// - Only works on Beneficial spells (not debuffs/detrimental effects)
    /// - Only works on the player's own buff bar (cannot remove buffs from NPCs/monsters)
    /// - Buffs cast by anyone (self or SimPlayers) can be removed
    /// </summary>
    public static class ClickOffBuffs
    {
        /// <summary>
        /// Patch StatusEffectIcon to handle click events for buff removal.
        /// We use a Postfix on Update to check for clicks since we can't add interfaces via Harmony.
        /// </summary>
        [HarmonyPatch(typeof(StatusEffectIcon), "Update")]
        public class StatusEffectIcon_Update_Patch
        {
            // Track which icon was clicked to prevent double-processing
            private static StatusEffectIcon _lastClickedIcon = null;
            private static float _clickCooldown = 0f;

            private static void Postfix(StatusEffectIcon __instance, bool ___mouseOver)
            {
                // Update cooldown
                if (_clickCooldown > 0f)
                    _clickCooldown -= Time.deltaTime;

                // Only process if mouse is over this icon and left mouse button clicked
                if (!___mouseOver || !Input.GetMouseButtonDown(0))
                    return;

                // Prevent double-clicks
                if (_clickCooldown > 0f && _lastClickedIcon == __instance)
                    return;

                // Check if the icon is actually showing a buff
                if (!__instance.Icon.enabled)
                    return;

                // Get the Stats component this icon reads from
                Stats stats = __instance.ReadStats;
                if (stats == null)
                    return;

                // Only allow clicking off buffs on the PLAYER
                if (stats != GameData.PlayerStats)
                    return;

                int slotIndex = __instance.SlotIndex;
                if (slotIndex < 0 || slotIndex >= stats.StatusEffects.Length)
                    return;

                StatusEffect statusEffect = stats.StatusEffects[slotIndex];
                if (statusEffect == null || statusEffect.Effect == null)
                    return;

                // Only allow clicking off BENEFICIAL spells (not debuffs/detrimental effects)
                if (statusEffect.Effect.Type != Spell.SpellType.Beneficial)
                {
                    Debug.Log($"[ClickOffBuffs] Cannot click off {statusEffect.Effect.SpellName} - not a beneficial spell");
                    return;
                }

                // All checks passed - remove the buff (regardless of who cast it)
                string spellName = statusEffect.Effect.SpellName;
                stats.RemoveStatusEffect(slotIndex);

                Debug.Log($"[ClickOffBuffs] Player clicked off {spellName}");
                UpdateSocialLog.LogAdd($"You clicked off {spellName}.", "lightblue");

                // Set cooldown to prevent rapid double-clicks
                _lastClickedIcon = __instance;
                _clickCooldown = 0.3f;
            }
        }
    }

    /// <summary>
    /// Increases the backward movement speed cap when player has movement speed buffs.
    /// The base game caps backward movement at 7f regardless of buffs.
    /// This patch allows a configurable percentage of movement speed buffs to also increase the backward cap.
    /// </summary>
    public static class BackwardSpeedCapFixer
    {
        /// <summary>
        /// Postfix patch for Stats.CalcStats() - recalculates actualRunSpeed with
        /// a higher backward cap if player has movement speed buffs.
        /// </summary>
        [HarmonyPatch(typeof(Stats), "CalcStats")]
        public class Stats_CalcStats_Patch
        {
            private static void Postfix(Stats __instance, float ___seRunSpeed)
            {
                // Get config value (0-100%)
                float buffPercent = Plugin.BackwardSpeedBuffPercent?.Value ?? 50f;

                // Skip if disabled or no buff or not retreating
                if (buffPercent <= 0f || !__instance.isRetreating || ___seRunSpeed <= 0f)
                    return;

                // Calculate new cap: base 7 + configured % of movement speed buff
                float buffMultiplier = buffPercent / 100f;
                float newCap = 7f + (___seRunSpeed * buffMultiplier);

                // Recalculate speed with new cap
                float speed = __instance.RunSpeed + ___seRunSpeed;
                if (speed > newCap)
                    speed = newCap;
                if (speed < 2f)
                    speed = 2f;

                __instance.actualRunSpeed = speed;
            }
        }
    }
}

