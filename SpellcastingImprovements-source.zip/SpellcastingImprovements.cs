using HarmonyLib;
using UnityEngine;

namespace SpellcastingImprovements
{
    /// <summary>
    /// Fixes spell stacking - when a higher level spell on the same line is cast,
    /// removes any existing lower level spells on that line first.
    /// The base game only blocks lower-level spells, but doesn't remove them when
    /// casting a higher-level replacement.
    /// </summary>
    [HarmonyPatch(typeof(Stats), "AddStatusEffect", new System.Type[] { typeof(Spell), typeof(bool), typeof(int), typeof(Character) })]
    public class Stats_RemoveLowerLevelSpells_Patch
    {
        // Run before the main AddStatusEffect to clean up lower-level spells
        [HarmonyPriority(Priority.High)]
        private static void Prefix(Stats __instance, Spell spell)
        {
            if (spell == null || spell.Type != Spell.SpellType.Beneficial)
                return;

            // Skip if Generic line (those don't stack-check)
            if (spell.Line == Spell.SpellLine.Generic)
                return;

            // Find and remove any lower-level spells on the same line
            for (int i = 0; i < __instance.StatusEffects.Length; i++)
            {
                var se = __instance.StatusEffects[i];
                if (se == null || se.Effect == null)
                    continue;

                // Same spell line, and existing spell is LOWER level
                if (se.Effect.Line == spell.Line && se.Effect.RequiredLevel < spell.RequiredLevel)
                {
                    Debug.Log($"[SpellcastingImprovements] Removing '{se.Effect.SpellName}' (level {se.Effect.RequiredLevel}) " +
                              $"to make room for '{spell.SpellName}' (level {spell.RequiredLevel})");
                    __instance.RemoveStatusEffect(i);
                }
            }
        }
    }

    /// <summary>
    /// Fixes the bug where beneficial spell status messages appear even when the spell
    /// doesn't take hold due to a higher level spell already being active.
    /// This is a bug in the base game where SpellVessel.ResolveSpell() shows the status
    /// message BEFORE checking CheckForHigherLevelSE().
    /// </summary>
    public static class SpellMessageFixer
    {
        // State tracking for beneficial spell resolution
        private static bool _isResolvingBeneficialSpell = false;
        private static Spell _currentSpell = null;
        private static bool _spellWasBlocked = false;

        /// <summary>
        /// Prefix patch for SpellVessel.ResolveSpell() - tracks when beneficial spells
        /// are being resolved and pre-checks if they'll be blocked.
        /// </summary>
        [HarmonyPatch(typeof(SpellVessel), "ResolveSpell")]
        public class SpellVessel_ResolveSpell_Patch
        {
            private static void Prefix(Spell ___spell, Stats ___targ)
            {
                if (___spell != null && ___spell.Type == Spell.SpellType.Beneficial)
                {
                    _isResolvingBeneficialSpell = true;
                    _currentSpell = ___spell;

                    // Pre-check if spell will be blocked by a higher level spell
                    if (___targ != null && ___targ.Myself != null && !___targ.Myself.Invulnerable)
                    {
                        _spellWasBlocked = ___targ.Myself.MyStats.CheckForHigherLevelSE(___spell);
                    }
                    else
                    {
                        _spellWasBlocked = false;
                    }
                }
            }

            private static void Postfix()
            {
                // Clean up state after ResolveSpell completes
                _isResolvingBeneficialSpell = false;
                _currentSpell = null;
                _spellWasBlocked = false;
            }
        }

        /// <summary>
        /// Prefix patch for UpdateSocialLog.LogAdd() - intercepts status effect messages
        /// during beneficial spell resolution and replaces them with "did not take hold"
        /// message if the spell was blocked.
        /// </summary>
        [HarmonyPatch(typeof(UpdateSocialLog), "LogAdd", typeof(string), typeof(string))]
        public class UpdateSocialLog_LogAdd_Patch
        {
            private static bool Prefix(ref string _string, ref string _colorAsString)
            {
                // Fast path - not resolving a beneficial spell
                if (!_isResolvingBeneficialSpell || _currentSpell == null)
                    return true;

                // Check if this is the status effect message for the current spell
                // The message format is "You " + spell.StatusEffectMessageOnPlayer
                if (_string.StartsWith("You ") && _currentSpell.StatusEffectMessageOnPlayer != null &&
                    _string.Contains(_currentSpell.StatusEffectMessageOnPlayer))
                {
                    if (_spellWasBlocked)
                    {
                        // Replace with "did not take hold" message in red
                        _string = "Your spell did not take hold.";
                        _colorAsString = "red";
                    }
                }

                return true; // Let the (possibly modified) message through
            }
        }
    }

    /// <summary>
    /// Allows players to click on their buff icons to remove beneficial spells.
    /// Single-clicking a buff icon removes the buff and all its effects.
    ///
    /// Restrictions:
    /// - Only works on Beneficial spells (not debuffs/detrimental effects)
    /// - Only works on the player's own buff bar (cannot remove buffs from NPCs/monsters)
    /// - Buffs cast by anyone (self or SimPlayers) can be removed
    /// </summary>
    public static class ClickOffBuffs
    {
        /// <summary>
        /// Patch StatusEffectIcon to handle click events for buff removal.
        /// We use a Postfix on Update to check for clicks since we can't add interfaces via Harmony.
        /// </summary>
        [HarmonyPatch(typeof(StatusEffectIcon), "Update")]
        public class StatusEffectIcon_Update_Patch
        {
            // Track which icon was clicked to prevent double-processing
            private static StatusEffectIcon _lastClickedIcon = null;
            private static float _clickCooldown = 0f;

            private static void Postfix(StatusEffectIcon __instance, bool ___mouseOver)
            {
                // Update cooldown
                if (_clickCooldown > 0f)
                    _clickCooldown -= Time.deltaTime;

                // Only process if mouse is over this icon and left mouse button clicked
                if (!___mouseOver || !Input.GetMouseButtonDown(0))
                    return;

                // Prevent double-clicks
                if (_clickCooldown > 0f && _lastClickedIcon == __instance)
                    return;

                // Check if the icon is actually showing a buff
                if (!__instance.Icon.enabled)
                    return;

                // Get the Stats component this icon reads from
                Stats stats = __instance.ReadStats;
                if (stats == null)
                    return;

                // Only allow clicking off buffs on the PLAYER
                if (stats != GameData.PlayerStats)
                    return;

                int slotIndex = __instance.SlotIndex;
                if (slotIndex < 0 || slotIndex >= stats.StatusEffects.Length)
                    return;

                StatusEffect statusEffect = stats.StatusEffects[slotIndex];
                if (statusEffect == null || statusEffect.Effect == null)
                    return;

                // Only allow clicking off BENEFICIAL spells (not debuffs/detrimental effects)
                if (statusEffect.Effect.Type != Spell.SpellType.Beneficial)
                {
                    Debug.Log($"[ClickOffBuffs] Cannot click off {statusEffect.Effect.SpellName} - not a beneficial spell");
                    return;
                }

                // All checks passed - remove the buff (regardless of who cast it)
                string spellName = statusEffect.Effect.SpellName;
                stats.RemoveStatusEffect(slotIndex);

                Debug.Log($"[ClickOffBuffs] Player clicked off {spellName}");
                UpdateSocialLog.LogAdd($"You clicked off {spellName}.", "lightblue");

                // Set cooldown to prevent rapid double-clicks
                _lastClickedIcon = __instance;
                _clickCooldown = 0.3f;
            }
        }
    }

    /// <summary>
    /// Increases the backward movement speed cap when player has movement speed buffs.
    /// The base game caps backward movement at 7f regardless of buffs.
    /// This patch allows a configurable percentage of movement speed buffs to also increase the backward cap.
    /// </summary>
    public static class BackwardSpeedCapFixer
    {
        /// <summary>
        /// Postfix patch for Stats.CalcStats() - recalculates actualRunSpeed with
        /// a higher backward cap if player has movement speed buffs.
        /// </summary>
        [HarmonyPatch(typeof(Stats), "CalcStats")]
        public class Stats_CalcStats_Patch
        {
            private static void Postfix(Stats __instance, float ___seRunSpeed)
            {
                // Get config value (0-100%)
                float buffPercent = Plugin.BackwardSpeedBuffPercent?.Value ?? 50f;

                // Skip if disabled or no buff or not retreating
                if (buffPercent <= 0f || !__instance.isRetreating || ___seRunSpeed <= 0f)
                    return;

                // Calculate new cap: base 7 + configured % of movement speed buff
                float buffMultiplier = buffPercent / 100f;
                float newCap = 7f + (___seRunSpeed * buffMultiplier);

                // Recalculate speed with new cap
                float speed = __instance.RunSpeed + ___seRunSpeed;
                if (speed > newCap)
                    speed = newCap;
                if (speed < 2f)
                    speed = 2f;

                __instance.actualRunSpeed = speed;
            }
        }
    }
}

